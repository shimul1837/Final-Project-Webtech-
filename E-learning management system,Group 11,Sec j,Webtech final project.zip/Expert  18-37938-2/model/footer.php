<!DOCTYPE html>
<html>
<head>
	<title>Footer</title>
</head>
<body>
  <p style="background-color:#AED6F1; text-align: center"><b>Developed by </b> <font color="#2980B9 "size="4px">&copy; Mazharul Islam </font></p>
</body>
</html>