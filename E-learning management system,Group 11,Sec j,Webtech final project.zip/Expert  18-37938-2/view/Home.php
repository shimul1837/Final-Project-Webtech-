<!DOCTYPE html>
<html>
<head>
	<title>Public Home Page</title>
</head>
<body>

	<?php require_once'../model/Welcome.php'?>
	
	<h1>Welcome to E Learning Management System</h1>
	
	<?php  require_once'../model/footer.php' ?>
	

</body>
</html>