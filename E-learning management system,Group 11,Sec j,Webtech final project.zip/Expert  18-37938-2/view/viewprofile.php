<?php require_once '../controller/viewcontrol.php';  ?> 


<!DOCTYPE html>
<html>
<head>
	<title>View Profile</title>
</head>
<body>

<center>

<fieldset>
<legend>View Profile</legend>
<p>Name : <?php echo $name ?></p>
<p>Username : <?php echo $uname ?></p>
<p>Email : <?php echo $email ?></p>

</fieldset>

</center>

</body>
</html>
<?php require_once'../model/footer.php'; ?>