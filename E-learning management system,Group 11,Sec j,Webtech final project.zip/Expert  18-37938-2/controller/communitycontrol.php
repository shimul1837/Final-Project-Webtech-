<?php 

$textarea = "";
if (isset($_POST['Post']))
 {
	$textarea = $_POST['textarea'];
}
?>