<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
  <?php
  session_start();
  if(isset($_SESSION['uname']))
  { echo '<div class="container">';
    echo '<div class="row justify-content-between">';
    echo '<div class="col-12 col-sm-2">';
    echo "<a href='welcome.php'><img src='img/eLogo.png' width='150' height='80'></a>";
    echo '</div>';
    echo '<div class="col-12 col-sm-3">';

    //echo "<div style='text-align:right;'>";
    echo "Logged in as "."<a href='viewProfile.php'>".$_SESSION['uname']."| </a>";
    echo "<a href=' logout.php'>Logout</a>";
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '';
    echo "<hr>";
    //echo "</div>";
  }else{
    echo '<div class="container">';
    echo '<div class="row justify-content-between">';
    echo '<div class="col-12 col-sm-2">';
  echo "<a href='publicHome.php'><img src='img/eLogo.png' width='150' height='80'></a>";
  echo '</div>';
    echo '<div class="col-12 col-sm-3">';
  echo "<div style='text-align:right;'>";
  echo "<a href='publicHome.php'>Home|</a>";
  echo "<a href='login.php'>Login</a>";
  echo '</div>';
    echo '</div>';
    echo '</div>';
  echo "<hr>";
  //echo "</div>";
}
  ?>
</body>
</html>