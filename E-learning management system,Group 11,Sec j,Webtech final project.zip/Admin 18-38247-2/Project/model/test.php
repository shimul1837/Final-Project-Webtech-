<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php
require_once "empModel.php";
$a="aaa";
$res=checkUsernameValidity($a);
echo $res;


?>


</body>
</html>