<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<hr>
<div class="container">
  <div class="row justify-content-between">
    <div class="col-12 col-sm-4">
<p>Copyright 2021 ©</p>
</div>
<div class="col-12 col-sm-2">
<a href="aboutUs.php">About Us</a>
</div>
</div>
</div>
</body>
</html>