<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div class="menu">
<ul style="list-style-type:none;">
<li><a href="welcome.php">Home</a></li>
<li><a href="teacherManagement.php">Teacher Management</a></li>
<li><a href="studentManagement.php">Student Management</a></li>
<li><a href="changePass.php">Change Password</a></li>
<li><a href="dashboard.php">Dashboard</a></li>
<li><a href="logout.php">Logout</a></li>
</div>
</body>
</html>