-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2021 at 08:31 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `uname` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `designation` varchar(40) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `dob` date NOT NULL,
  `dp` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `email`, `uname`, `password`, `designation`, `gender`, `dob`, `dp`) VALUES
(11, 'Fahim Ahmed', 'ahmed.fahim37@gmail.com', 'random', '$2y$12$p2JpyqczJNj61me8JNEd2O0QehGx5grgT', 'web_developer', 'male', '1998-10-15', '1.png'),
(12, 'Sadat', 'sadat@mail.com', 'sadat', '$2y$12$goU/QKANkffHEEZA/5aDveR95/KYpt3DQ', 'business_analysts', 'male', '2021-07-07', ''),
(13, 'Sakib', 'sakib@mail.com', 'sakib', '$2y$12$P11Ek/n4GJhW64qOE2Hrwu6AibyJ/GNjQ', 'customer_service_representative', 'male', '2021-08-06', ''),
(14, 'Sharmin', 'sarmin@mail.com', 'Sharmin', '$2y$12$LlGKK0qWOwAVjeSvTFOhv.gM9NjIoxvI4', 'delivery_driver', 'female', '2021-08-06', ''),
(16, 'test', 'test@t.com', 'test', '$2y$12$AGN57Clv/F2GIspvTTT5ve/Qr/2/VGDOC', 'delivery_driver', 'male', '2021-08-06', 'Capture.PNG');

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `id` int(11) NOT NULL,
  `sname` varchar(40) NOT NULL,
  `semail` varchar(40) NOT NULL,
  `suname` varchar(40) NOT NULL,
  `spass` varchar(40) NOT NULL,
  `spcategory` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`id`, `sname`, `semail`, `suname`, `spass`, `spcategory`) VALUES
(4, 'emon', 'emon@mail.com', 'emon', '$2y$12$4w/m0do3onmPeBIRa05J7uI.W5V6mmvko', 'vehicle'),
(6, 'Fahim Ahmed', 'ahmed.fahim37@gmail.com', 'fahim', '$2y$12$vdF9daMeW2FiEdwI6Rfnp.bNpiObsPFeA', 'electronics');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
