<!DOCTYPE html>
<html>
<body>

<ul>
  <li><a href="welcome.php">Home</a></li>
  <li><a href="logout.php">Logout</a></li>

</ul>


</body>
</html>