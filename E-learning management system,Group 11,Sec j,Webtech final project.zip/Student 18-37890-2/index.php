
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Cagliostro' rel='stylesheet' type='text/css'>
<link href="web/css/style.css" rel="stylesheet" type="text/css" media="all" />
<!--slider-->
<link href="web/css/camera.css" rel="stylesheet" type="text/css" media="all" />
    <script type='text/javascript' src="web/js/jquery.min.js"></script>
    <script type='text/javascript' src="web/js/jquery.mobile.customized.min.js"></script>
    <script type='text/javascript' src="web/js/jquery.easing.1.3.js"></script> 
    <script type='text/javascript' src="web/js/camera.min.js"></script> 
      <script>
		jQuery(function(){
			
			jQuery('#camera_wrap_4').camera({
				height: 'auto',
				loader: 'bar',
				pagination: false,
				thumbnails: true,
				hover: false,
				opacityOnGrid: false,
				imagePath: 'web/images/'
			});

		});
	</script>
</head>
<body>
<div class="wrap">
<div class="wrapper">
<div class="logo">
	<a href="index.php"><h2>E Learning</h2></a>
</div>
<div class="header_right">
	<div class="cssmenu">
		<ul>
		  	<li class="active"><a href="index.php"><span>Home</span></a></li>
			<li><a href="login.php"><span>Login</span></a></li>
			<li class="has-sub"><a href="registration.php"><span>Registration</span></a></li>
			<li class="last"><a href="contact.php"><span>Contact</span></a></li>
			<div class="clear"></div>
		 </ul>
	</div>
</div>
	<div class="clear"></div>
</div>
</div>
<div class="fluid_container">
   <div class="camera_wrap camera_emboss pattern_1" id="camera_wrap_4">
          <div data-src="web/images/slider1.jpg"> </div>
            <div data-src="web/images/slider2.jpg"> </div>
            <div  data-src="web/images/slider3.jpg"> </div>
  </div>
</div>
	<div class="clear"></div>
<div class="wrap">
<div class="wrapper">
<div class="main_text">
		<h2>A place of light, of liberty, and learning</h2>
		<h3>we provide leading intensive courses</h3>
	</div>	
	<div class="grids_1_of_4">
				<div class="grid_1_of_4 images_1_of_4 bg1">
					 <img src="web/images/icon1.png">
				</div>
				<div class="grid_1_of_4 images_1_of_4 bg2">
					 <img src="web/images/icon2.png">
				</div>
				<div class="grid_1_of_4 images_1_of_4 bg3 hide">
					 <img src="web/images/icon3.png">
				</div>
				<div class="grid_1_of_4 images_1_of_4 bg4 hide">
					 <img src="web/images/icon4.png">
				</div>
			
	</div>
	</div>
<div class="main_bg">
<div class="wrap">
<div class="wrapper">
	<div class="main">
			
			<div class="grid_1_of_2 images_1_of_2 img_style">
				<img src="web/images/pic1.jpg" alt="">
			</div>
			<div class="clear"></div>
	</div>
</div>
</div>
</div>
<div class="wrap">
<div class="wrapper">
	<div class="footer">
		<div class="social-icons">
	   		  	<ul>
			      <li class="icon_1"><a href="#" target="_blank"> </a></li>
			      <li class="icon_2"><a href="#" target="_blank"> </a></li>
			      <li class="icon_3"><a href="#" target="_blank"> </a></li>
			      <li class="icon_4"><a href="#" target="_blank"> </a></li>
			      <div class="clear"></div>
		     </ul>
	   	 </div>
		<div class="copy">
			<p class="w3-link">E-Learning | &copy; 2021</p>
		</div>
	</div>
</div>
<div class="clear"></div>
</div>
</body>
</html>