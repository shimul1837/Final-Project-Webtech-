<?php
session_start();
     unset($_SESSION['un']);
	 header('location:login.php');
?>
   