<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 0.2b
 */

//
// Database `college`
//

// `college`.`registration`
$registration = array(
  array('regdate' => '30/04/2016','first_name' => 'VINAY','last_name' => 'S M','father_name' => 'MADEGOWDA','mother_name' => 'RADHA','dob' => '08/09/1993','gender' => 'MALE','course' => 'MCA','sem' => 'FOURTH','register_no' => '15MCAL58','address' => 'SREE RAMANAGARA','city' => 'BHADRAVATHI','pin' => '577301','phno' => '9945543108','email' => 'vinaysmgowda@gmail.com','photo' => 'IMG_20160409_094423.jpg','username' => 'vinay','password' => 'gowda','status' => 'accept')
);

// `college`.`subject_master`
$subject_master = array(
  array('sub_id' => '2','subject' => 'JAVA','logo' => 'Desert.jpg')
);

// `college`.`tbl_notes_details`
$tbl_notes_details = array(
  array('notes_id' => '7','course' => 'MCA','subject' => 'JAVA','topic' => 'INTRODUCTION','date' => '30/04/2016','notes' => 'os_linux.pdf','video' => 'bomb.mp4','summary' => '')
);
